# Welcome!

Swordible.io is a multiplayer .io game where players fight each other with different swordsand try to gain coins. The more coins you have, the bigger and powerful you get! Try to become the biggest of them all.

## Community
* [Forum](soon)
* [Discord](soon)
