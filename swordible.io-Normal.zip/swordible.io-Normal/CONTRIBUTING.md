In order to contribute you will have to edit the code and make a pull request, then CoderGautam will review it and see if it will work out good. We do suggest you to have Discord although.

When contributing you must have these requirements:

1. Knowing basic coding
2. Must not make a file that contains viruses/computer damage and request it as a pull request.
3. You must never make a SwordBattle.io exploit

These are mainly suggested in order to be a good contributor!
